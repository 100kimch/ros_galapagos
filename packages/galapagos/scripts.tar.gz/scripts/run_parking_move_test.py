import rospy
from sensor_msgs.msg import LaserScan
from std_msgs.msg import Int8MultiArray
from turtlebot import *


# parking informations 
left_distance = Int8MultiArray()
right_distance = Int8MultiArray()

LEFT = 1
RIGHT = 2
parking_space = 0               # 0 : cannot parking yet / 1 : LEFT spot / 2 : RIGHT spot
parking_enable = False          # True : arrive at parking spot / False : not yet


def parking_move():
    TURTLE.set_angular(-0.11)
    TURTLE.set_speed_test(0.7)
    TURTLE.move()
    rospy.sleep(rospy.Duration(2))

    TURTLE.set_angular(-0.1)
    TURTLE.set_speed_test(0)
    TURTLE.move()
    rospy.sleep(rospy.Duration(1.7))

    TURTLE.set_angular(0)
    TURTLE.set_speed_test(0)
    TURTLE.move()
    rospy.sleep(wait_time)

    TURTLE.set_angular(0.1)
    TURTLE.set_speed_test(0)
    TURTLE.move()
    rospy.sleep(rospy.Duration(1.7))

    TURTLE.set_angular(0.11)
    TURTLE.set_speed_test(-0.7)
    TURTLE.move()
    rospy.sleep(rospy.Duration(2))
    
    TURTLE.set_angular(0)
    TURTLE.set_speed_test(0)
    TURTLE.move()	


def lidar_test(lidar):
    global left_distance; global right_distance; global parking_enable; global parking_space
    global LEFT; global RIGHT

	right_distance = _lidar.ranges[270:330]
	left_distance = _lidar.ranges[120:180]

    # select parking space : left or right 
    for i in left_distance:
        if i < 0.12:
            parking_enable = True
			parking_space = LEFT
	for i in right_distance:
        if i < 0.12:
            parking_enable = True
            parking_space = RIGHT
    
    print(parking_enable,' ',parking_space)

parking_move()

rospy.init_node('parking', anonymous=True)
rospy.Subscriber('/scan', LaserScan, lidarscan_parking)   
rospy.spin()