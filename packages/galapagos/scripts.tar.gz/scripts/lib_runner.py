#!/usr/bin/env python3

import sys
from time import sleep
import rospy
from turtlebot import TURTLE

# * Variables
NAME = 'lib_runner'
TIME = rospy.Duration(1.6)

print("----- GALAPAGOS TURTLE -----")

# * Main Codes
if __name__ == '__main__':
    try:
        RUN_TYPE = 'run_' + sys.argv[1]
        rospy.loginfo("executing: %s" % RUN_TYPE)
        __import__('%s' % (RUN_TYPE), fromlist=[RUN_TYPE])
        rospy.loginfo("Galapagos package started.")
        rospy.spin()
    except rospy.ROSInterruptException:
        pass
    except KeyboardInterrupt:
        print("\r", end='')

    TURTLE.disable()
    # TODO: change time function to "await"
    for i in [3, 2, 1]:
        print("Turning off in %d s...\r" % i, end='')
        sleep(1)
    print("See you.                        ")
