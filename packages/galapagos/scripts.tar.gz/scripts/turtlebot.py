""" This module makes turtlebot"""
#!/usr/bin/env python3

import rospy
from geometry_msgs.msg import Twist
# from std_msgs.msg import Int8
from constants import MAX_SPEED, SPEED_VALUES, RUN_MODE

NAME = 'main_runner'


class Turtle(dict):
    """ an object how to run the TurtleBot3 """

    def __init__(self):
        """ __init__
        _angular: the value to set position
        """
        self._enable = True
        self._angular = 0
        self._speed = 0
        self._publisher_velocity = rospy.Publisher(
            '/cmd_vel', Twist, queue_size=5)
        # self._publisher_stage = rospy.Publisher('/stage', Int8, queue_size=5)
        # rospy.spin()
        self.stop()
        rospy.on_shutdown(self.stop)
        self.exitflag = False
        dict.__init__(self)

    def stop(self):
        """ stop the running bot """
        twist = Twist()
        twist.linear.x = 0
        twist.linear.y = 0
        twist.linear.z = 0
        twist.angular.x = 0
        twist.angular.y = 0
        twist.angular.z = 0
        self._publisher_velocity.publish(twist)

    def move(self):
        """ move the bot """
        if not self._enable:
            return
        # print('linear: %f / angular: %f' % (self._linear, self._angular))
        # if RUN_MODE == 'debug':
        #     rospy.loginfo('linear: %f / angular: %f' %
        #                   (self._linear, self._angular))
        twist = Twist()
        twist.linear.x = self._linear
        twist.linear.y = 0
        twist.linear.z = 0
        twist.angular.x = 0
        twist.angular.y = 0
        twist.angular.z  = self._angular
        self._publisher_velocity.publish(twist)

    def turn(self, direction, radius, duration):
        """ turn to direction with radius by duration """
        # TODO: finish code this:

    def increase_speed(self):
        self._linear += 0.1

    def decrease_speed(self):
        self._linear -= 0.1

    def disable(self):
        self.stop()
        self._enable = False

    def enable(self):
        self._enable = True

    # * setting functions

    def set_speed_by_percentage(self, percentage):
        """ set the speed by percentage """
        self._linear = MAX_SPEED * percentage
        # self.move()

    def set_speed(self, speed_str):
        """ set the speed by string """
        self._speed = MAX_SPEED * SPEED_VALUES[speed_str]

    def set_spped_test(self, speed):
        self._speed = speed

    def set_angular(self, angular):
        """ set the angular value """
        self._angular = angular
        # self.move()

    # * getting functions

    def get_speed(self):
        """ get the speed value """
        return self._linear

    def get_angular(self):
        """ get the angular value """
        return self._angular

    def get_info(self):
        """ get some information of turtlebot """
        return {
            'angluar': self._angular,
            'linear': self._speed,
        }


rospy.init_node(NAME, anonymous=True)
TURTLE = Turtle()
