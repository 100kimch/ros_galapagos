#!/usr/bin/env python3

import rospy
from sensor_msgs.msg import CompressedImage
import processor
from constants import PATH_RASPICAM, PATH_USBCAM

rospy.Subscriber(PATH_RASPICAM,
                 CompressedImage, processor.test_line_tracing, queue_size=1)
