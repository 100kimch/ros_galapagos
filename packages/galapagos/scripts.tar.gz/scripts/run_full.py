#!/usr/bin/env python3

import rospy
from sensor_msgs.msg import CompressedImage
import processor
from constants import PATH_RASPICAM, PATH_USBCAM, PATH_LIDAR

rospy.Subscriber(PATH_RASPICAM, CompressedImage,
                 processor.process_fish_image, queue_size=1)
rospy.Subscriber(PATH_USBCAM,
                 CompressedImage, processor.process_front_image, queue_size=1)
# rospy.Subscriber('/lidar' + PATH_LIDAR,
#                  """something""", processor.process_lidar, queue_size=1)
# rospy.Subscriber('/usb_cam' + PATH_USBCAM,
#                 CompressedImage, processor.process_usbcam_image, queue_size=1)
