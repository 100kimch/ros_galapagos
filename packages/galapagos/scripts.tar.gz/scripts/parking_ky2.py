import rospy
import cv2
import numpy as np
from std_msgs.msg import Int8MultiArray
from std_msgs.msg import Int8
from sensor_msgs.msg import LaserScan
# Ros Messages
# We do not use cv_bridge it does not support CompressedImage in python
# from cv_bridge import CvBridge, CvBridgeError
from sensor_msgs.msg import CompressedImage
import time
time = rospy.Duration(1.6)


###################################################################################
####################<<< Initial Value Definition >>>###############################

### HSV range used in white detect
lower_white = np.array([0,0,200]) 
upper_white = np.array([180,15,255])


# parking informations 
left_distance = Int8MultiArray()
right_distance = Int8MultiArray()

parking_space = 0               # 0 : cannot parking yet / 1 : LEFT spot / 2 : RIGHT spot
white_detected = False
cnt_line = 0


######################################################################################
#################################<<< Funtions >>>#####################################

### Funtion that save the distance from lidar
def lidarscan_parking(_lidar): 
	''' lidar scanning call back function
		* Input
			lidar : lidar scan datas
	'''
	global left_distance; global right_distance
	right_distance = _lidar.ranges[270:330]
	left_distance = _lidar.ranges[120:180]


def set_blobdetector(): 
	''' set the params of blob detector for making white line ROI detector 
		* Output
			detector : blob detector
	'''
	# Setup SimpleBlobDetector parameters.
	params = cv2.SimpleBlobDetector_Params()
		 
	# Change thresholds
	params.minThreshold = 0;
	params.maxThreshold = 256;
		 
	# Filter by Area.
	params.filterByArea = True
	params.minArea = 1000
	params.maxArea=400000
		 
	# Filter by Circularity
	params.filterByCircularity = True
	params.minCircularity = 0.1
		 
	# Filter by Convexity
	params.filterByConvexity = True
	params.minConvexity = 0.1
		 
	# Filter by Inertia
	params.filterByInertia = False
	params.minInertiaRatio = 0.01
		 
	# Create a detector with the parameters
	ver = (cv2.__version__).split('.')
	if int(ver[0]) < 3 :
	    detector = cv2.SimpleBlobDetector(params)
	else : 
	    detector = cv2.SimpleBlobDetector_create(params)
	return detector



def whiteblob_detecting(_input_img): 
	''' detect white blob at parking_state
		* Input
			_input_img : input image from usb camera
		* Output
			centers / blob_centers : center point of blob = ROI center
    '''
    global lower_white; global upper_white

    ### draw ROI
	cv2.line(_input_img,(int(_input_img.shape[1]*6.1/9),0),(int(_input_img.shape[1]*6.1/9),_input_img.shape[0]),(255,0,255),4) 						#! code for debugging
	cv2.line(_input_img,(int(_input_img.shape[1]*2.9/9),0),(int(_input_img.shape[1]*2.9/9),_input_img.shape[0]),(255,0,255),4)						#! code for debugging
	cv2.line(_input_img,(int(_input_img.shape[1]*2.9/9),_input_img.shape[0]),(int(_input_img.shape[1]*6.1/9),_input_img.shape[0]),(255,0,255),4)	#! code for debugging
	cv2.line(_input_img,(int(_input_img.shape[1]*2.9/9),0),(int(_input_img.shape[1]*6.1/9),0),(255,0,255),4)										#! code for debugging

	blob_detector = white_setting()	
	blob_ROI = _input_img[:,_input_img.shape[1]*3/9:_input_img.shape[1]*6/9] ### setting ROI
		
	hsv_white = cv2.cvtColor(blob_ROI, cv2.COLOR_BGR2HSV) ### process rgb_image to hsv_image 
	mask_white = cv2.inRange(hsv_white, lower_white,upper_white)

	reversemask = 255 - mask_white ### Detect blobs
	blob_centers = detector.detect(reversemask)

    cv2.imshow('hsv white',hsv_white)                                                                    #! code for debugging
    cv2.imshow('mask white',mask_white)                                                                  #! code for debugging
    cv2.imshow('reversemask white',reversemask)                                                          #! code for debugging
    cv2.waitKey()                                                                                        #! code for debugging

    if len(blob_centers) >= 1: 
        centers=[]		
        for i in blob_centers:
            centers.append(i.pt)
        return centers
    else: 
        return blob_centers


def line_detecting(_input_img): 
	''' detect line at parking state	
		* Input
			_input_img : input image from usb camera
		* Output
			count_line : number of detected lines
	'''
	ROI_line = _input_img[:,_input_img.shape[1]*3.8/9:_input_img.shape[1]*5.2/9] ### setting ROI

	ROI_gray = cv2.cvtColor(ROI_gray,cv2.COLOR_BGR2GRAY) ### Image process to make detecting line easy	
	ROI_gray = cv2.GaussianBlur(ROI_gray,(7,7),0)
	ROI_binary = cv2.adaptiveThreshold(ROI_gray,255,cv2.ADAPTIVE_THRESH_GAUSSIAN_C,cv2.THRESH_BINARY,11,2)
	ROI_binary = cv2.medianBlur(ROI_binary,9)	
	ROI_edge = cv2.Canny(ROI_binary,180,360)

	lines = cv2.HoughLines(ROI_edge,1,np.pi/180,120) ### detecting lines
	
    count_line = 0 ### line initializing
	if lines is not None:
		lines=[l[0] for l in lines]
		for line in lines:
			r,th = line
			a = np.cos(th)
			b = np.sin(th)
			x0 = a*r
			y0 = b*r
			x1 = int(x0+1000*(-b))
			y1 = int(y0+1000*a)
			x2 = int(x0-1000*(-b))
			y2 = int(y0-1000*a)
						
			cv2.line(_input_img,(x1+int(_input_img.shape[1]*3.8/9),y1),(x2+int(_input_img.shape[1]*3.8/9),y2),(255,0,255),5)				#! code for debugging
			count_line +=1  ### line count				

    cv2.imshow('line',_input_img)                                                                  #! code for debugging
    cv2.waitKey()                                                                                  #! code for debugging

	return count_line ### return number of line


def making_parkinginfo(_webcam_img): 
	''' detecting possible parking spot : left or right spot
	### using web_cam, check white_blob and line and enough distance, if all exist, it send Availablity
		* Input
			_webcam_img : input image from webcam
		* Output

	'''
    global left_distance; global right_distance; global white_detected; global parking_space
    
    ### image pre_processing
    np_arr 		= np.fromstring(_webcam_img.data, np.uint8) 
    frame 		= cv2.imdecode(np_arr, cv2.IMREAD_COLOR)
    hsv 		= cv2.cvtColor(frame,cv2.COLOR_BGR2HSV)
    mask_white 	= cv2.inRange(hsv,lower_white,upper_white)
    result 		= cv2.bitwise_and(frame,frame,mask=mask_white)

    cv2.imshow('input_image',frame)                                                             #! code for debugging
   	cv2.imshow('white mask',result)                                                             #! code for debugging
    cv2.waitKey(1)&0xFF																			#! code for debugging

    ### Checking if there are lines
    total_linenumber = line_detecting(frame)

    ### Checking if there are white
    centers 	= whiteblob_detecting(frame) 
	
    ### check white line
    if (total_linenumber > 0) and centers:
	    white_detected = True   		
   	else:
    	white_detected = False
	
	print(white_detected)																		#! code for debugging

    # select parking space : left or right 
    for i in left_distance:
	    if (i > 0.12) and (i < 0.6):
			parking_space = 1
	for i in right_distance:    
		if (i > 0.12) and (i < 0.6):
			parking_space = 2

### Function that run when stage = PARKING
def move_parking(angular): 

	global cnt_line; global parking_space; global white_detected
	print(cnt_line)																				#! code for debugging

	# go straight until finding white line 
	if cnt_line == 0:
        if white_detected == False:
			turtlemove(0.1,angular)
			return 'PARKING'
        else:
			cnt_line = 1
			return 'PARKING'
		
	# after finding first parking line
	# go stratight until finding no white line
	# when finding no white line spot -> select parking direction
	elif cnt_line == 1:
        if white_detected == True:
            turtlemove(0.1,angular)
			return 'PARKING'

		elif white_detected == False:
			# right side parking
			if parking_space == 2:
				turtlemove(0.11,-0.7)
				rospy.sleep(rospy.Duration(2))
				turtlemove(0.1,0)
				rospy.sleep(rospy.Duration(1.7))
				turtlemove(0,0)
				rospy.sleep(time)
				turtlemove(-0.1,0)
				rospy.sleep(rospy.Duration(1.7))
				turtlemove(-0.11,0.7)
				rospy.sleep(rospy.Duration(2))
				turtlemove(0,0)	
				return 'NORMAL'   # finish parking
			# left side parking
			elif parking_space == 1:
				#TODO: have to test and make code
				turtlemove(0.11,0.7)
				rospy.sleep(rospy.Duration(2))
				turtlemove(0.1,0)
				rospy.sleep(rospy.Duration(1.7))
				turtlemove(0,0)
				rospy.sleep(time)
				turtlemove(-0.1,0)
				rospy.sleep(rospy.Duration(1.7))
				turtlemove(-0.11,-0.7)
				rospy.sleep(rospy.Duration(2))
				turtlemove(0,0)	
				return 'NORMAL'
			else:
				if angular<1.9:		
					turtlemove(0.09,angular)
				else:
					turtlemove(0.06,0)


rospy.init_node('parking', anonymous=True)
def scan_ladar():
	rospy.Subscriber("/usb_cam/image_raw/compressed",CompressedImage, making_parkinginfo,  queue_size = 1)
	rospy.Subscriber('/scan', LaserScan, lidarscan_parking)   
	rospy.spin()

###########################################################################################################
#! code for testing start
state = 'PARKING'															
scan_ladar()																
while state == 'PARKING':													
	state = move_parking(angular)											

if state == 'NORMAL':														
	print 'FINISH!!'
	rospy.loginfo('FINISH!!')															
else:
	print 'ERROR!!'
	rospy.loginfo('ERROR!!')															
#! code for testing end