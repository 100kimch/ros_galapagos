#! /usr/bin/env python3

import rospy
from constants import LIDAR_DIRECTIONS, RUN_MODE

# * Variables
LIDAR_VALUES = {
    'front': 0.00,
    'right': 0.00,
    'back': 0.00,
    'left': 0.00
}


def set_lidar_values(lidar_data):
    """ set lidar value to LIDAR_VALUES """
    global LIDAR_VALUES
    for (value, key) in enumerate(LIDAR_VALUES):
        LIDAR_VALUES[key] = lidar_data.ranges[LIDAR_DIRECTIONS[key]]
    if RUN_MODE == 'debug':
        rospy.loginfo('LIDAR_VALUES: %s' % LIDAR_VALUES)


def get_object_distance(direction):
    return LIDAR_VALUES[direction]


def is_in_tunnel(lidar_data):
    """ check if the turtlebot is in tunnel """
    return False / True
