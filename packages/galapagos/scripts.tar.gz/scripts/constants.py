""" constants """
#!/usr/bin/env python3

PATH_RASPICAM = '/raspicam_node/image/compressed'
PATH_USBCAM = '/usb_cam/image_raw/compressed'
PATH_LIDAR = '/scan'
PATH_ASSETS = '../assets/'

MAX_SPEED = 0.15
SPEED_VALUES = {
    'fast': 1,
    'normal': 0.7,
    'slow': 0.3,
    'stop': 0
}

RUN_MODE = 'debug'
#RUN_MODE = 'nono'
RUN_TYPE = ''

#############################################################
ARRAY_K = [[480.,     0,  320.],
           [0.,   320.,   240.],
           [0.,   0.,  1.]]
# [  [클수록 아래볼록 작을수록 위볼록] , [+ :오른쪽치우침, - :왼쪽치우침] , ]
ARRAY_D = [0., 0., 0., 0.]
#### modified by minsoo -190810 ##############################

SIGNAL_IMAGES = {
    'parking': 'parking.jpg',
    'left': 'left.png',
    'right': 'right.png',
    'three': 'T_2.png'
}

# threshold values
THRESHOLD_PARKING = 26
# threshold values
THRESHOLD_LEFT_RIGHT_MIN = 8
# threshold values
THRESHOLD_LEFT_RIGHT_MAX = 17
# threshold values
THRESHOLD_INTERSECTION = 15

DEFAULT_LIDAR_DEGREE = 4

# NOTE: New Contstants
THRESHOLDS = {
    'parking': 26,
    'left_right_min': 8,
    'left_right_max': 17,
    'intersection': 15,
}

LIDAR_DIRECTIONS = {
    'top': 0,
    'left': 90,
    'back': 180,
    'right': 270
}
