#!/usr/bin/env python3

import rospy
from sensor_msgs.msg import LaserScan, CompressedImage
import processor
from constants import PATH_LIDAR, PATH_RASPICAM

rospy.Subscriber('/lidar' + PATH_LIDAR,
                 """something""", processor.process_lidar_data, queue_size=1)
