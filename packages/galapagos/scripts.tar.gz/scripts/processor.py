#!/usr/bin/env python3

from lib_line_tracing import *
from lib_signal_recognition import *
from lib_lidar import *
from turtlebot import TURTLE

# * Variables
CURRENT_STATE = 'traffic_light'
LINE_BASE = 'both'
MOVING_POSITION = False
SEEN_PARKING_SIGN = False
SEEN_TUNNEL_SIGN = False
IS_IN_TUNNEL = False
SEEN_STOPPING_SIGN = False

DISTANCE_FRONT = 0.00
IS_IN_TUNNEL = False
HAS_OBJECT_IN_50 = False
HAS_OBJECT_IN_20 = False

# * Methods


def reset_front_image_flags():
    global LINE_BASE
    global MOVING_POSITION
    global SEEN_PARKING_SIGN
    global SEEN_TUNNEL_SIGN
    global HAS_OBJECT_IN_FRONT
    global SEEN_STOPPING_SIGN
    LINE_BASE = 'both'
    MOVING_POSITION = False
    SEEN_PARKING_SIGN = False
    SEEN_TUNNEL_SIGN = False
    SEEN_STOPPING_SIGN = False


def process_front_image(image):
    """ process the image of raspicam """
    global CURRENT_STATE
    global MOVING_POSITION
    global SEEN_PARKING_SIGN
    global SEEN_TUNNEL_SIGN
    global LINE_BASE
    global SEEN_STOPPING_SIGN

    if CURRENT_STATE == 'traffic_light':
        if is_light_green(image):
            TURTLE.set_speed('fast')
            CURRENT_STATE = 'normal'
            return

    if CURRENT_STATE == 'normal':
        sign = check_sign(image)

        if sign == 'intersection':
            CURRENT_STATE = 'intersection'

        elif sign == 'construction':
            MOVING_POSITION = 'left'
            CURRENT_STATE = 'construction'

        elif sign == 'parking':
            SEEN_PARKING_SIGN = True
            return

        elif HAS_OBJECT_IN_50:
            CURRENT_STATE = 'blocking_bar'

        elif sign == 'tunnel':
            SEEN_TUNNEL_SIGN = True
            return

        if is_intersection(image):
            CURRENT_STATE = 'parking'

        if is_in_tunnel(image):
            CURRENT_STATE = 'tunnel'

        if has_curve_in(10, image):
            TURTLE.set_speed('normal')

        elif is_straight_in(50, image):
            TURTLE.increase_speed()

        else:
            TURTLE.decrease_speed()

    if CURRENT_STATE == 'intersection':
        TURTLE.set_speed('normal')

        sign_intersection = check_left_right_sign(image)
        if sign_intersection == 'none':
            LINE_BASE = 'both'
        else:
            if sign_intersection == 'left':
                LINE_BASE = 'left'
            elif sign_intersection == 'right':
                LINE_BASE = 'right'

            if is_stopping_sign(image):
                SEEN_STOPPING_SIGN = True
            else:
                if SEEN_STOPPING_SIGN:
                    CURRENT_STATE = 'normal'
                else:
                    return

    if CURRENT_STATE == 'construction':
        TURTLE.set_speed("slow")
        if HAS_OBJECT_IN_20:
            TURTLE.turn(MOVING_POSITION, 15, 3)
            if MOVING_POSITION == 'left':
                MOVING_POSITION = 'right'
            else:
                MOVING_POSITION = 'left'
            return
        else:
            if has_crossing_line(image):
                if MOVING_POSITION == 'left':
                    moving_to = 'right'
                else:
                    moving_to = 'left'
                TURTLE.turn(moving_to, 15, 3)
            else:
                # TODO: combine trace_line() + trace_blocking()
                if get_num_of_lines(image) == 2:
                    CURRENT_STATE = 'normal'
                else:
                    return

    if CURRENT_STATE == 'parking':
        # TODO: finish code of parking state
        TURTLE.set_speed('normal')
        return

    if CURRENT_STATE == 'blocking_bar':
        # TODO: finish code of blocking_bar state
        TURTLE.set_speed('normal')

        return

    if CURRENT_STATE == 'tunnel':
        # TODO: finish code of tunnel state
        TURTLE.set_speed('normal')
        return

    # ending the normal state:
    if CURRENT_STATE == 'normal':
        reset_front_image_flags()
        TURTLE.set_speed('fast')
        return


def process_fish_image(image):
    """ process the fisheye lens image """
    global LINE_BASE

    trace_line(image)
    TURTLE.move()


def process_usbcam_image(compressed_image):
    """ process the image of usb webcam """
    return


def process_lidar_data(lidar_data):
    """ process the lidar data """
    global IS_IN_TUNNEL
    global DISTANCE_FRONT

    set_lidar_values(lidar_data)

    DISTANCE_FRONT = get_object_distance('front')

    IS_IN_TUNNEL = is_in_tunnel(lidar_data)


def test_line_tracing(image):
    trace_line(image)
    # gogo()


def test_sudden_stop(image):
    global DISTANCE_FRONT

    if RUN_MODE == 'debug':
        rospy.logdebug('fish_image received')

    process_fish_image(image)

    if DISTANCE_FRONT == 0:
        TURTLE.enable()
        rospy.loginfo('turtlebot enabled.')
    elif DISTANCE_FRONT < 0.20:
        TURTLE.stop()
        rospy.loginfo('turtlebot stopped.')
        return
    elif DISTANCE_FRONT < 0.50:
        # TODO: decrease speed
        pass

    # trace_line(image)
    TURTLE.set_speed_by_percentage(1)
    TURTLE.move()


# * Initialization
reset_front_image_flags()
